var ipDesignOptions = {

   bodyBackgroundColor: function (value) {

       'use strict';

       $('body').css('text-color', value);

   }

};