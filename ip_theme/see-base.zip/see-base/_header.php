﻿<h1 id="siteheader">see-base</h1>

<nav id="nav">
	<?php
		/*echo ipSlot('menu',array('items'=>'navigationsleiste'));*/
		echo ipSlot('menu','navigation');
	?>
</nav>