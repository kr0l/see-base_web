<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width" />
<meta name="description" content="###" />
<meta name="author" content="###" />
<?php ipAddCss('assets/css/style.css'); ?>
<?php echo ipHead(); ?>
<link href="assets/pictures/favicon.png" rel="shortcut icon">
<title>see-base || Der Hackerspace am Bodensee</title>